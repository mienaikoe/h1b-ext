<script lang="ts">
  export let label: string = "";
  export let value: string | number = "";
</script>

<div class="dts-companyDetail">
  <div class="dts-label">{label}</div>
  <div class="dts-value">{value}</div>
</div>

<style src="./CompanyDetail.less"></style>
